import TimelineSection from '../TimelineSection';

export default function TimelineSectionExample() {
  return <TimelineSection />;
}
